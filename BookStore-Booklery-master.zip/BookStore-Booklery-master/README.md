** MongoDB Connection **
-> Create a .env file in your code editor :
--PORT="Your PORT number"
--MONGODB_URI="Yor MongoDB URI"

**To Run Backend **
-> cd backend
->npm start

//Run both simultaneously in two diff terminals 

**To Run Frontend **
->cd frontend
-> npm run dev
